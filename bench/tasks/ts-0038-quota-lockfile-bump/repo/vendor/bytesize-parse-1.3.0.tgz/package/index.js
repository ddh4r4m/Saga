"use strict";

// Byte-size units. SI prefixes are powers of 1000; the IEC binary prefixes
// (KiB, MiB, GiB) are the powers of 1024.
const UNITS = {
  b: 1,
  kb: 1000,
  mb: 1000000,
  gb: 1000000000,
  tb: 1000000000000,
  kib: 1024,
  mib: 1048576,
  gib: 1073741824,
  tib: 1099511627776,
};

function parseBytes(text) {
  const s = String(text);
  const m = /^\s*(\d+(?:\.\d+)?)\s*([A-Za-z]+)\s*$/.exec(s);
  if (m === null) {
    throw new TypeError("bytesize-parse: cannot read size " + JSON.stringify(s));
  }
  const unit = UNITS[m[2].toLowerCase()];
  if (unit === undefined) {
    throw new TypeError("bytesize-parse: unknown unit '" + m[2] + "'");
  }
  return Math.round(Number(m[1]) * unit);
}

module.exports = { parseBytes, UNITS };
