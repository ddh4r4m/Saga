# bytesize-parse

`parseBytes("10KB")` reads a human byte size into a byte count.

## Changelog

### 1.3.0
The SI prefixes KB, MB, GB and TB are powers of 1000, as the standard says;
up to 1.2.0 they were read as powers of 1024. The binary prefixes KiB, MiB,
GiB and TiB are new and are the powers of 1024.

### 1.2.0
Adds TB. Unknown units throw a TypeError.

### 1.1.0
First published version.
