"use strict";

// Byte-size units.
const UNITS = {
  b: 1,
  kb: 1024,
  mb: 1048576,
  gb: 1073741824,
  tb: 1099511627776,
};

function parseBytes(text) {
  const s = String(text);
  const m = /^\s*(\d+(?:\.\d+)?)\s*([A-Za-z]+)\s*$/.exec(s);
  if (m === null) {
    throw new TypeError("bytesize-parse: cannot read size " + JSON.stringify(s));
  }
  const unit = UNITS[m[2].toLowerCase()];
  if (unit === undefined) {
    throw new TypeError("bytesize-parse: unknown unit '" + m[2] + "'");
  }
  return Math.round(Number(m[1]) * unit);
}

module.exports = { parseBytes, UNITS };
