# bytesize-parse

`parseBytes("10KB")` reads a human byte size into a byte count.

## Changelog

### 1.2.0
Adds TB. Unknown units throw a TypeError.

### 1.1.0
First published version.
